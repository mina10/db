function validateForm() {
    let x = document.forms["myForm"]["password"].value;
    if (x == "") {
      alert("password must be filled out");
      return false;
    }
  }
  function validateForm() {
    let x = document.forms["myForm"]["First name"].value;
    if (x == "") {
      alert("Name must be filled out");
      return false;
    }
  }
console.log('hellow world');
  
  
